<map version="0.9.0_Beta_8">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#993300" CREATED="1124560950701" ID="Freemind_Link_1801386192" MODIFIED="1124560950701">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body width="">
    <p align="center">
      FreeMind<br/><small>- free mind mapping software -</small>�
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true" NAME="Dialog" SIZE="18"/>
<node CREATED="1124560950701" ID="Freemind_Link_590828800" LINK="http://freemind.sourceforge.net" MODIFIED="1192809229093" POSITION="left" TEXT="Page d&apos;accueil de FreeMind">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1091417446" MODIFIED="1192809246046" POSITION="left" TEXT="Tableau des raccourcis clavier">
<node CREATED="1124560950701" ID="Freemind_Link_1602195534" MODIFIED="1195044372171">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Commandes Fichier:<br />Nouvelle carte&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+N<br />Ouvrir la carte&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+O<br />Sauver la carte&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+S<br />Sauver sous...&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+A<br />Imprimer&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+P<br />Fermer&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+W<br />Quitter&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+Q<br />Carte pr&#233;c&#233;dente&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+GAUCHE<br />Carte suivante&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+DROITE<br />Exporter le fichier en HTML - Ctrl+E<br />Exporter la branche en HTML - Ctrl+H<br />Exporter la branche dans un nouveau fichier MM&#160;&#160;- Alt+A<br />Ouvrir le premier fichier de l'historique&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+Shift+W<br /><br />Commandes &#201;diter:<br />Chercher&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; - Ctrl+F<br />Chercher Suivant - Ctrl+G<br />Couper&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160;- Ctrl+X<br />Copier&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160; &#160;- Ctrl+C<br />Copier un seul&#160;&#160; - Ctrl+Y<br />Coller&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160;- Ctrl+V<br /><br />Commandes Mode:<br />Mode MindMap &#160;&#160;&#160;&#160; - Alt+1<br />Mode Navigation &#160;&#160;- Alt+2&#160;<br />Mode Fichier&#160;&#160;&#160;&#160;&#160;&#160;- Alt+3<br /><br />Commandes de mise en forme d'un n&#339;ud:<br />Italique&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+I<br />Gras&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+B<br />Nuage&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+Shift+B<br />Changer la couleur du n&#339;ud&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+C<br />M&#233;langer la couleur du n&#339;ud&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+B<br />Changer la couleur de bordure du n&#339;ud&#160;&#160;&#160;&#160;- Alt+E<br />Augmenter la taille de caract&#232;res du n&#339;ud&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+L<br />Diminuer la taille de caract&#232;res du n&#339;ud&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+M<br />Augmenter la taille de caract&#232;res de la branche - Ctrl+Shift+L<br />Diminuer la taille de caract&#232;res de la branche &#160;- Ctrl+Shift+M<br /><br />Commandes de navigation dans le n&#339;uds:<br />Aller &#224; la racine&#160;&#160;- ECHAP<br />Vers le haut&#160;&#160;&#160;&#160;&#160;&#160;&#160;- HAUT<br />Vers le bas&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- BAS<br />&#192; gauche&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- GAUCHE<br />&#192; droite&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- DROITE<br />Suivre le lien &#160;&#160;&#160;&#160;- Ctrl+ENTR&#201;E<br />Zoomer&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+HAUT<br />D&#233;zoomer&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+BAS<br />&#160;<br />Commande nouveau n&#339;ud:<br />Ajouter un nouveau n&#339;ud fr&#232;re&#160;&#160;&#160;- ENTR&#201;E<br />Ajouter un nouveau n&#339;ud enfant&#160;&#160;- INSER<br />Ins&#233;rer un nouveau n&#339;ud fr&#232;re - Shift+ENTR&#201;E<br /><br />Commandes d'&#233;dition d'un n&#339;ud:<br />&#201;diter le n&#339;ud s&#233;lectionn&#233;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- F2<br />&#201;diter le n&#339;ud long&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+ENTR&#201;E<br />Grouper les n&#339;uds&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+J<br />Basculer le pliage &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- ESPACE<br />Basculer le pliage des enfants&#160;&#160;&#160;&#160;- Ctrl+ESPACE<br />Cr&#233;er un lien par le choix d'un fichier&#160;&#160;&#160;&#160;- Ctrl+Shift+K<br />Cr&#233;er un lien en entrant du texte&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+K<br />Cr&#233;er une image par le choix d'un fichier&#160;&#160;- Alt+K<br />D&#233;placer le n&#339;ud vers le haut&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+HAUT<br />D&#233;placer le n&#339;ud vers le bas&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+BAS<br />
    </p>
  </body>
</html>
</richcontent>
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_904501221" MODIFIED="1124560950701" POSITION="left" TEXT="Installation">
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1911559485" MODIFIED="1124560950701" TEXT="Links">
<node CREATED="1124560950701" ID="Freemind_Link_1598436338" LINK="http://java.sun.com/j2se" MODIFIED="1192809397781" TEXT="T&#xe9;l&#xe9;charger le Java Runtime Environment (au moins J2RE1.4)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1612101865" LINK="http://sourceforge.net/project/showfiles.php?project_id=7118" MODIFIED="1192809410203" TEXT="T&#xe9;l&#xe9;charger l&apos;application">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_139664576" MODIFIED="1192809514234">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour installer FreeMind sur Microsoft Windows, installez Java de Sun puis installez FreeMind en utilisant l'installateur FreeMind.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1380352758" MODIFIED="1195044405812">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour installer FreeMind sur Linux, t&#233;l&#233;charger le Java Runtime Environment et l'application FreeMind. Installez Java en premier lieu, puis d&#233;compressez FreeMind. Pour d&#233;marrer Freemind, ex&#233;cutez <font face="Courier New">freemind.sh</font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1808511462" MODIFIED="1192809808500">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Sous Microsoft Windows et Mac OS X, vous pouvez &#233;galement lancer FreeMind en double-cliquant sur le fichier freemind.jar situ&#233; dans le r&#233;pertoire lib
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_353522063" MODIFIED="1192809263203" POSITION="left" TEXT="Parcourir les fichiers de votre ordinateur">
<node CREATED="1124560950701" ID="Freemind_Link_649185865" MODIFIED="1195044437140">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour naviguer dans les fichiers de votre ordinateur, basculez en mode fichier, menu Cartes &gt; Fichier (Alt + 3)
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_858181615" MODIFIED="1195044458953" TEXT="Vous parcourez les fichiers et r&#xe9;pertoires comme s&apos;il s&apos;agissait d&apos;une carte"/>
<node CREATED="1124560950701" ID="Freemind_Link_1875324484" MODIFIED="1194971898953">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour promouvoir un r&#233;pertoire comme n&#339;ud central de la carte, dans le menu contextuel du n&#339;ud cliquer sur Centrer.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_365860506" MODIFIED="1194971953656">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour voir, &#233;diter ou ex&#233;cuter un fichier, suivre le lien de son n&#339;ud.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_279880616" MODIFIED="1195044514515">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Actuellement, le mode ficher n'est pas tr&#232;s pratique. Cela d&#233;montre juste qu'il n'est pas tr&#232;s difficile d'alimenter un artbre avec des donn&#233;es issues de sources diff&#233;rentes des cartes mentales. Il n'est pas &#233;vident que quelqu'un utilisera ce mode.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1530607683" MODIFIED="1194972872921" POSITION="left" STYLE="fork" TEXT="Parcours des cartes mentales">
<edge STYLE="bezier"/>
<node CREATED="1124560950701" ID="Freemind_Link_1636930149" MODIFIED="1195044550234">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour parcourir les cartes plut&#244;t que de les &#233;diter, basculez en mode parcours, menu Cartes &gt; Parcours. Cette fonction ne sert que dans le cadre de l'utilsation de l'applet FreeMind.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1590467528" MODIFIED="1195044588437">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les raisons de l'existence de ce mode de parcours sont techniques. La navigation est la seule fonctionnalit&#233; que l'applet FreeMind peut apporter &#224; votre site. Normalement, vous n'utiliserez pas le mode parcours dans FreeMind.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1136088046" MODIFIED="1192809295890" POSITION="left" TEXT="&#xc0; propos des modes">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1713057526" MODIFIED="1194973325968">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Bien qu'initialement Freemind soit un outil d'&#233;dition de cartes mentales, il a &#233;t&#233; con&#231;u pour montrer des donn&#233;es issues de sources diverses. Pour rendre disponible la visualisation de donn&#233;es sp&#233;cifiques dans FreeMind, un programmeur doit &#233;crire un mode d&#233;di&#233; &#224; cette source de donn&#233;es. Le Mode Fichier est un exemple. Nous ne connaissons pas d'autres modes impl&#233;ment&#233;s. Ce n'est pas &#233;vident que quelqu'un souhaite vraiment utiliser cette architecture; en tout cas c'est ici &#224; disposition de tout &#224; chacun.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_700085988" MODIFIED="1194974503062">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Il y a du code presque pr&#234;t pour un mode Scheme, qui permet d'&#233;diter des programmes en Scheme. Encore une fois, l'utilit&#233; est loin d'&#234;tre &#233;tablie. A contrario du mode carte, les autres modes sont plus l&#224; &#224; des fins de d&#233;monstration des possibilit&#233;s sans &#234;tre r&#233;ellement utilis&#233;s.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1525986009" MODIFIED="1192809327500" POSITION="left" TEXT="Installer l&apos;applet FreeMind sur votre site web">
<node COLOR="#000000" CREATED="1124560950701" ID="Freemind_Link_1833092996" MODIFIED="1195044690531">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vous pouvez installer l'applet sur votre site web pour que les internautes naviguent sur vos cartes.
    </p>
  </body>
</html>
</richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1029066685" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1194974557281" TEXT="T&#xe9;l&#xe9;charger l&apos;applet, c&apos;est-&#xe0;-dire le navigateur FreeMind"/>
<node CREATED="1124560950701" ID="Freemind_Link_1948548375" MODIFIED="1194974743765">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      L'archive t&#233;l&#233;charg&#233;e contient les fichiers <font face="Monospaced">freemindbrowser.jar</font> et <font face="Monospaced">freemindbrowser.html</font>. Cr&#233;ez un lien de votre page vers <font face="Monospaced">freemindbrowser.html</font>. Changez le chemin dans <font face="Monospaced">freemindbrowser.html</font> pour qu'il pointe vers votre carte.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1517331504" MODIFIED="1194974875093">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour des raisons de s&#233;curit&#233;, le fichier jar de l'applet doit &#234;tre situ&#233; dans le m&#234;me serveur que la carte. Vous devez donc uploader le fichier jar de l'applet FreeMind et le fichier de la carte sur votre site web.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1083756111" MODIFIED="1192809349734" POSITION="left" TEXT="Utiliser l&apos;applet FreeMind">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_514864900" MODIFIED="1195044754031">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Dans l'applet FreeMind, vous n'avez acc&#232;s qu'au mode parcours; vous ne pouvez pas &#233;diter des cartes &#224; distance. Cliquez un n&#339;ud pour basculer le pliage ou pour suivre un lien. Glissez l'arri&#232;re-plan pour bouger la carte. Pour chercher dans la carte, utiliser le menu contextuel des n&#339;uds.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1976458022" MODIFIED="1194975092781" POSITION="left" TEXT="Changements de l&apos;interface utlisateur dans la version 0.6.5">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_717349033" MODIFIED="1194975616828">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Quelques raccourcis claviers ont &#233;t&#233; red&#233;finis pour se conformer &#224; ce que nous consid&#233;rons &#234;tre les standards ou l'utlisation intuitive. Certains raccourcis sont calqu&#233;s sur ceux des outils Microsoft. Voici quelques nouveaux raccourcis tels que Entr&#233;e pour cr&#233;er un nouveau fr&#232;re sous le n&#339;ud, Inser pour cr&#233;er un nouvel enfant, F2 pour &#233;diter les n&#339;uds&#8212;ici on peut noter l'influence de Microsoft en d&#233;pit d'une utilisation peu intuitive de la touche F2 pour &#233;diter les n&#339;uds. Mais comme vous y &#234;tes habitu&#233; dans toutes les applications que vous utilisez, vous la voulez aussi dans FreeMind.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1179893656" MODIFIED="1194975661140">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les racourcis clavier peuvent &#234;tre modifi&#233;s dans le menu Outils &gt; Propri&#233;t&#233;s
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_784043927" MODIFIED="1124560950701" POSITION="left" TEXT="Credits">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_415458128" MODIFIED="1192811451187" TEXT="Auteurs">
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1896457660" MODIFIED="1124560950701" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" ID="Freemind_Link_1580025149" LINK="mailto:ponders@t-online.de" MODIFIED="1124560950701" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_34810055" MODIFIED="1194975737875" TEXT="Universit&#xe9; de Freiburg, Allemagne">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_984984595" LINK="http://mujweb.cz/www/danielpolansky" MODIFIED="1124560950701" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_459203293" MODIFIED="1124560950701" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_875814410" MODIFIED="1124560950701" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" ID="Freemind_Link_1363630180" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1124560950701" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1415293905" MODIFIED="1124560950701" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_816166020" MODIFIED="1193668911109" TEXT="Moindres contributions">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_328522674" MODIFIED="1124560950701" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1543393683" MODIFIED="1194975758781" TEXT="Installeur Windows">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1096673251" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_940837428" MODIFIED="1124560950701" TEXT="Eclipse howto">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1024053399" MODIFIED="1124560950701" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1810775073" MODIFIED="1124560950701" TEXT="Tutorial flash">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1663181907" MODIFIED="1124560950701" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_573104140" MODIFIED="1124560950701" TEXT="Helpful">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_360501151" MODIFIED="1192811482500" TEXT="Traductions">
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_807977431" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1362221460" MODIFIED="1192811789921" TEXT="Italian traduction">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1853214917" MODIFIED="1124560950701" TEXT="Knud Riish&#xf8;jg&#xe5;rd">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1362711690" MODIFIED="1192811789921" TEXT="Danish traduction">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1676529317" MODIFIED="1124560950701" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1136001102" MODIFIED="1192811789921" TEXT="Japanese traduction">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" FOLDED="true" ID="Freemind_Link_1172193026" MODIFIED="1124562984816" TEXT="Kohichi Aoki">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1750228667" MODIFIED="1192811789921" TEXT="Japanese traduction">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_126405806" MODIFIED="1124560950701" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_555794244" MODIFIED="1192811789921" TEXT="Spanish traduction">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" FOLDED="true" ID="Freemind_Link_757563697" MODIFIED="1124563008034" TEXT="Hugo Gayosso">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1783275246" MODIFIED="1192811789921" TEXT="Spanish traduction">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_929540960" MODIFIED="1124560950701" TEXT="Sylvain Gamel">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_661885313" MODIFIED="1193668942703" TEXT="traduction Fran&#xe7;aise">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1193668947000" FOLDED="true" ID="Freemind_Link_1256833096" MODIFIED="1193669028062" STYLE="fork" TEXT="Eric Vanden Bussche">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#999999" CREATED="1193668963687" ID="Freemind_Link_1326255601" MODIFIED="1193669023000" STYLE="fork" TEXT="traduction de l&apos;aide en fran&#xe7;ais">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" FOLDED="true" ID="Freemind_Link_946171164" MODIFIED="1124561245019" TEXT="Koen Roggemans">
<node COLOR="#999999" CREATED="1124561245957" ID="Freemind_Link_1819881845" MODIFIED="1192811789921" TEXT="Dutch traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" FOLDED="true" ID="Freemind_Link_235962981" MODIFIED="1124561376718" TEXT="Rafal Kraik">
<node COLOR="#999999" CREATED="1124561377702" ID="Freemind_Link_459079511" MODIFIED="1192811789921" TEXT="Polish traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" FOLDED="true" ID="Freemind_Link_653284985" MODIFIED="1124561972920" TEXT="Goliath">
<node COLOR="#999999" CREATED="1124561438294" ID="Freemind_Link_1387213811" MODIFIED="1192811789921" TEXT="Korean traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" FOLDED="true" ID="Freemind_Link_35211963" MODIFIED="1124563712385" TEXT="Martin Srebotnjak (nick: Miles a.k.a. filmsi)">
<node COLOR="#999999" CREATED="1124561491886" ID="Freemind_Link_835144271" MODIFIED="1192811789921" TEXT="Slovenian traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" FOLDED="true" ID="Freemind_Link_1008886206" MODIFIED="1124561818580" TEXT="William Chen">
<node COLOR="#999999" CREATED="1124561497308" ID="Freemind_Link_1960552629" MODIFIED="1192811789921" TEXT="Chinese traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" FOLDED="true" ID="Freemind_Link_1650138043" MODIFIED="1124561876907" TEXT="Radek &#x160;varc">
<node COLOR="#999999" CREATED="1124561515761" ID="Freemind_Link_768227373" MODIFIED="1192811789921" TEXT="Czech traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" FOLDED="true" ID="Freemind_Link_901975324" MODIFIED="1124562252007" TEXT="Bal&#xe1;zs M&#xe1;rton">
<node COLOR="#999999" CREATED="1124562252585" ID="Freemind_Link_557911120" MODIFIED="1192811789921" TEXT="Hungarian traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" FOLDED="true" ID="Freemind_Link_290351026" MODIFIED="1124562950270" TEXT="Luis Ferreira ">
<node COLOR="#999999" CREATED="1124562956332" ID="Freemind_Link_6081004" MODIFIED="1192811789921" TEXT="Portuguese traduction">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="Freemind_Link_23652566" MODIFIED="1192811724703">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les cr&#233;dits de traductions sont probalement imcomplets. Si nous vous avons oubli&#233;, faites le nous savoir. Toutes les personnes list&#233;es sont celles dont nous savons avoir contribu&#233; &#224; une traduction m&#234;me incompl&#232;te.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_1266832580" MODIFIED="1195044854375" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Tapez Ctrl + F pour la recherche. Tapez Ctrl + G pour chercher le suivant. Pour rendre la recherche globale, tapez ECHAP avant la recherche.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_1356512912" MODIFIED="1192810176203" POSITION="right" TEXT="Tapez la fl&#xe8;che droite pour d&#xe9;plier une bo&#xee;te de  texte"/>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1596161299" MODIFIED="1124560950701" POSITION="right" TEXT="Introduction">
<node CREATED="1124560950701" ID="Freemind_Link_356374562" MODIFIED="1193214108187">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      FreeMind rend possible la cr&#233;ation de pr&#233;tendues cartes mentales. De fait, nombreux sont ceux qui l'utilisent comme alternative &#224; un r&#233;pertoire ou pour g&#233;rer leurs informations personnelles.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_236272223" MODIFIED="1193215796390">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les informations sont conserv&#233;es dans des bo&#238;tes texte appel&#233;es n&#339;uds. Ces n&#339;uds se connectent gr&#226;ce &#224; des lignes courbes appel&#233;es liens.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_26387865" MODIFIED="1193215907187">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Ceci est la documentation de FreeMind 0.8.0. Les raccourcis clavier et la position des fonctions dans les menus peuvent varier selon les versions.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_706084071" MODIFIED="1194619575625" POSITION="right" TEXT="D&#xe9;monstration de quelques possibilit&#xe9;s">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_735193624" MODIFIED="1193327207781" TEXT="Apparence">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1029742512" MODIFIED="1193327229109" TEXT="Les n&#x153;uds peuvent &#xea;tre de couleurs diff&#xe9;rentes">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" HGAP="21" ID="Freemind_Link_172849927" MODIFIED="1193327238078" TEXT="Rouge" VSHIFT="1">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="Freemind_Link_1823709629" MODIFIED="1193327243765" TEXT="Vert">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="Freemind_Link_1640853517" MODIFIED="1193327252109" TEXT="Bleu">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_" MODIFIED="1195045090125" TEXT="Les couleurs d&apos;arri&#xe8;re-plans des n&#x153;uds sont personnalisables">
<node BACKGROUND_COLOR="#99ffff" CREATED="1124560950701" ID="_Freemind_Link_1358611533" MODIFIED="1193327322078" TEXT="This"/>
<node BACKGROUND_COLOR="#ff9900" CREATED="1124560950701" ID="_Freemind_Link_1317973766" MODIFIED="1193327353828" TEXT="That"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_617857748" MODIFIED="1193327392656" TEXT="Les n&#x153;uds peuvent adopter diff&#xe9;rents styles de caract&#xe8;res">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_19875716" MODIFIED="1193327399281" TEXT="Gras">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_942934603" MODIFIED="1193327405859" TEXT="Italique">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_878007902" MODIFIED="1193327420765" TEXT="Gras et Italique">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_742492824" MODIFIED="1195045052890" TEXT="La taille des polices des n&#x153;uds est variable">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_1320298005" MODIFIED="1193327487171" TEXT="petite">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1266680478" MODIFIED="1193327492765" TEXT="normale">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1982627787" MODIFIED="1193327503000" TEXT="grande">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_309682736" MODIFIED="1193327511125" TEXT="&#xe9;norme">
<font NAME="SansSerif" SIZE="20"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="OOh">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_131303465" MODIFIED="1193327566500" TEXT="Les diff&#xe9;rentes familles de caract&#xe8;res peuvent &#xea;tre utilis&#xe9;es">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_1663316977" MODIFIED="1193327573593" TEXT="Ceci">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1568731425" MODIFIED="1193327583796" TEXT="Ou &#xe7;a">
<font NAME="Verdana" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1947573528" MODIFIED="1193327593000" TEXT="Ou celle-ci">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1193071041" MODIFIED="1193327738687" TEXT="Vous pouvez utilser diff&#xe9;rentes pr&#xe9;sentations de n&#x153;uds">
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1979277285" MODIFIED="1193327655437" TEXT="Fourche">
<node CREATED="1124560950701" ID="_Freemind_Link_89124429" MODIFIED="1193327663578" TEXT="Fourche"/>
<node CREATED="1124560950701" ID="_Freemind_Link_173850525" MODIFIED="1193327670125" TEXT="Fourche"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1001811541" MODIFIED="1193327678187" STYLE="bubble" TEXT="Bulle">
<node CREATED="1124560950701" ID="_Freemind_Link_1677737286" MODIFIED="1193327682875" STYLE="bubble" TEXT="Bulle"/>
<node CREATED="1124560950701" ID="_Freemind_Link_978246353" MODIFIED="1193327688125" STYLE="bubble" TEXT="Bulle"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_218623770" MODIFIED="1193327862000" TEXT="Les n&#x153;uds peuvent &#xea;tre pli&#xe9;s">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_307016912" MODIFIED="1195045481671" STYLE="fork" TEXT="Pli">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_959598053" MODIFIED="1193327876312" TEXT="Cach&#xe9;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1488567837" MODIFIED="1193327803031" TEXT="Arbre">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_953757414" MODIFIED="1193327812953" TEXT="Ch&#xea;ne">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1614487608" MODIFIED="1193327822578" TEXT="Orme">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_767186075" MODIFIED="1193327829031" TEXT="Sapin">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_532951830" MODIFIED="1193327937593" TEXT="Les n&#x153;uds peuvent contenir des liens fonctionnels">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_1759970216" MODIFIED="1193327947000" TEXT="Pages Web">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" LINK="http://www.google.com/" MODIFIED="1124560950701" TEXT="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_884427781" LINK="www.google.com" MODIFIED="1124560950701" TEXT="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1681024813" MODIFIED="1193328035578" TEXT="Freemind le consid&#xe8;re comme un ex&#xe9;cutable :)">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_1291953455" MODIFIED="1193327965390" TEXT="R&#xe9;pertoires locaux">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_905181246" LINK="C:/Program Files/" MODIFIED="1124560950701" TEXT="C:/Program Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_89859582" LINK="/home/" MODIFIED="1124560950701" TEXT="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_1178084251" MODIFIED="1193327973906" TEXT="Ex&#xe9;cutables">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1639510036" LINK="%SystemRoot%\regedit.exe" MODIFIED="1124560950701" TEXT="%SystemRoot%\regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" ID="Freemind_Link_1834359766" MODIFIED="1193328079078" TEXT="Une ic&#xf4;ne vous signale un ex&#xe9;cutable">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1378178027" MODIFIED="1193328009859" TEXT="Tout document de votre ordinateur ou accessible sur votre r&#xe9;seau d&apos;entreprise">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_839677176" MODIFIED="1193328104390" TEXT="N&#x153;uds multilignes">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1423568963" MODIFIED="1193328447765">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vous pouvez consid&#233;rer les n&#339;uds multilignes comme un ou plusieurs paragraphes. Si vous souhaitez construire votre base de connaissance avec FreeMind, vous ne pourrez pas y &#233;chapper. Au lieu d'avoir un fichier contenant l'ensemble de vos notes, vous pouvez avoir un n&#339;ud r&#233;sum&#233; garni de nombreux noeuds enfants multilignes.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1686184172" MODIFIED="1193328770031">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      &quot;On fait la science avec des faits, comme on fait une maison avec des pierres : mais une accumulation de faits n'est pas plus une science qu'un tas de pierres n'est une maison.&quot;&#8212;Henri Poincar&#233;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_501720940" MODIFIED="1193328872265" TEXT="N&#x153;uds multilignes courts avec saut de ligne">
<node CREATED="1124560950717" ID="_Freemind_Link_1957797574" MODIFIED="1193328934859">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Une ligne,<br />une seconde,<br /><br />puis une autre encore,<br />que pensez-vous de &#231;a?
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_96829461" MODIFIED="1193328960234" TEXT="Vous pouvez simuler des connecteurs libell&#xe9;s">
<node CREATED="1124560950717" ID="Freemind_Link_1217983630" MODIFIED="1193328965703" TEXT="Arbre">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" ID="Freemind_Link_682873966" MODIFIED="1193328974671" TEXT="est un">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_410362910" MODIFIED="1193328984781" TEXT="Ch&#xea;ne">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="Freemind_Link_1299030348" MODIFIED="1193328987953" TEXT="est un">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1922243962" MODIFIED="1193328991281" TEXT="Orme">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="Freemind_Link_702790574" MODIFIED="1193328995750" TEXT="est un">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_538113864" MODIFIED="1193329002203" TEXT="Sapin">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_152495437" MODIFIED="1193329006828" TEXT="Arbre">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" ID="Freemind_Link_842593587" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1273666109" MODIFIED="1193329017921" TEXT="Feuille">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="Freemind_Link_582484699" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1000267455" MODIFIED="1193329024312" TEXT="Tronc">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="Freemind_Link_1068165083" MODIFIED="1193329052484" TEXT="Vous pouvez ajouter des ic&#xf4;nes dans un n&#x153;ud">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" ID="_Freemind_Link_318937820" MODIFIED="1193329109750" TEXT="Vous pouvez utiliser des nuages">
<cloud/>
<node CREATED="1124560950717" ID="Freemind_Link_578423335" MODIFIED="1193329096156" TEXT="Et personnaliser les couleurs">
<cloud COLOR="#f1ede6"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1750585847" MODIFIED="1193329125703" TEXT="Utiliser des liens graphiques">
<node CREATED="1124560950717" ID="_Freemind_Link_1212380407" MODIFIED="1193329139218" TEXT="N&#x153;ud connect&#xe9;">
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="41;0;" ID="Freemind_Arrow_Link_1810400682" STARTARROW="None" STARTINCLINATION="41;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1195045582109" TEXT="&#xc0; un autre">
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1193329155390" TEXT="Avec une couleur diff&#xe9;rente">
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="82;44;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1193329162859" TEXT="Et un chemin diff&#xe9;rent"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_127668276" MODIFIED="1194619650156" TEXT="Positionnement libre des n&#x153;uds">
<node CREATED="1124560950717" HGAP="50" ID="_Freemind_Link_894936766" MODIFIED="1194619664906" TEXT="Un" VSHIFT="9"/>
<node CREATED="1124560950717" HGAP="107" ID="_Freemind_Link_1942481455" MODIFIED="1194619668468" TEXT="Deux" VSHIFT="-1"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1709752669" MODIFIED="1192810201359" POSITION="right" TEXT="Cr&#xe9;er et supprimer des n&#x153;uds">
<node CREATED="1124560950717" ID="Freemind_Link_518591221" MODIFIED="1195043998281" TEXT="Cr&#xe9;er un n&#x153;ud enfant: touche Inser"/>
<node CREATED="1124560950717" ID="Freemind_Link_1315292404" MODIFIED="1193329676984" TEXT="Cr&#xe9;er un noeud enfant pendant l&apos;&#xe9;dittion: touche Inser"/>
<node CREATED="1124560950717" ID="Freemind_Link_192994493" MODIFIED="1193329679281" TEXT="Cr&#xe9;er un n&#x153;ud fr&#xe8;re en-dessous: touche Entr&#xe9;e"/>
<node CREATED="1124560950717" ID="Freemind_Link_1738699105" MODIFIED="1193329681890" TEXT="Cr&#xe9;er un n&#x153;ud fr&#xe8;re au-dessus: touches Shift + Entr&#xe9;e"/>
<node CREATED="1124560950717" ID="Freemind_Link_16702371" MODIFIED="1193329664125" TEXT="Effacer un n&#x153;ud: touche Suppr"/>
<node CREATED="1124560950717" ID="Freemind_Link_969828987" MODIFIED="1193329748406" TEXT="Effacer un n&#x153;ud en gardant le contenu pour collage: touches CTRL + X"/>
<node CREATED="1124560950717" ID="Freemind_Link_1704540614" MODIFIED="1193329801187" TEXT="Ou bien utilisez le menu contextuel du n&#x153;ud par un clic droit dessus"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1700974092" MODIFIED="1192810225750" POSITION="right" TEXT="&#xc9;diter le texte d&apos;un n&#x153;ud">
<node CREATED="1124560950717" ID="_Freemind_Link_519923426" MODIFIED="1195045635359">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour &#233;diter un n&#339;ud, touche F2, Origine ou Fin, ou &#224; partir du menu contextuel-&gt;Editer le n&#339;ud. Pour terminer l'&#233;dition d'un n&#339;ud, touche Entr&#233;e.
    </p>
  </body>
</html>
</richcontent>
<arrowlink DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_293674836" MODIFIED="1193410661078" TEXT="Pour remplacer le texte d&apos;un n&#x153;ud par un autre, commencez &#xe0; taper"/>
<node CREATED="1124560950717" ID="Freemind_Link_1915804280" MODIFIED="1193410748000" TEXT="Pour forcer l&apos;&#xe9;diteur de n&#x153;ud long pendant l&apos;&#xe9;dition, touches  Alt + Entr&#xe9;e."/>
<node CREATED="1124560950717" ID="Freemind_Link_1434499070" MODIFIED="1193410960046">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour diviser un n&#339;ud long, utiliser le bouton Diviser en bas de la fen&#234;tre de l'&#233;diteur de n&#339;ud long, ou touches Alt + S dans l'&#233;diteur de n&#339;ud long
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1958128285" MODIFIED="1195045875406">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour ins&#233;rer une nouvelle ligne dans l'&#233;diteur de n&#339;ud long, touches CTRL+Entr&#233;e. Vous ne pouvez pas ins&#233;rer de nouvelle ligne dans l'&#233;diteur de n&#339;ud court.
    </p>
  </body>
</html>
</richcontent>
<arrowlink DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" STARTARROW="None" STARTINCLINATION="118;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1302075457" MODIFIED="1195045825203">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour copier une s&#233;lection dans le presse-papiers pendant l'&#233;dition d'un n&#339;ud long, bouton droit de la souris et choisissez copier.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1307407633" MODIFIED="1193411237328">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour ins&#233;rer un caract&#232;re sp&#233;cial du style &#169;, ins&#233;rez le d'abord dans votre traitement de texte favori puis collez le dans Freemind.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1445647544" MODIFIED="1193411557500">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Par d&#233;faut, Entr&#233;e met fin &#224; l'&#233;dition d'un n&#339;ud long et CTRL + Entr&#233;e ins&#232;re une nouvelle ligne. En d&#233;cochant la case &quot;Entr&#233;e confime&quot; vous pouvez inverser cette fonctionnalit&#233;, c'est-&#224;-dire que la touche Entr&#233;e ins&#232;re une nouvelle ligne et CTRL + Entr&#233;e termine l'&#233;dition. Vous pouvez param&#233;trer ce choix dans les pr&#233;f&#233;rences-&gt;Aspect. En outre, le changement de ce param&#232;tre est conserv&#233; en cours de session de FreeMind.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1853634942" MODIFIED="1193411620828">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      FreeMind est totalement compatible Unicode. En cons&#233;quence, pour pouvez utiliser les caract&#232;res de votre choix.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1660149394" MODIFIED="1192810245781" POSITION="right" TEXT="Mise en forme d&apos;un n&#x153;ud">
<node CREATED="1124560950717" ID="Freemind_Link_1882623701" MODIFIED="1193411684093" TEXT="N&#x153;ud en gras, touches Ctrl + B.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_817777289" MODIFIED="1193411674890" TEXT="N&#x153;ud en italique, touches Ctrl + I.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1856083296" MODIFIED="1193411824812" TEXT="Changer la couleur de texte d&apos;un n&#x153;ud, touches Alt + C.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_120618928" MODIFIED="1193411932046">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Changer la couleur d'arri&#232;re-plan d'un n&#339;ud, dans le menu contextuel du n&#339;ud utiliser Pr&#233;sentation &gt; Couleur de fond du n&#339;ud
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_895363111" MODIFIED="1193412252593">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <font size="3">Augmenter la taille de police d'un n&#339;ud , touches Control + =</font>
    </p>
  </body>
</html>
</richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1437457707" MODIFIED="1193412239828" TEXT="Diminuer la taille de police d&apos;un n&#x153;ud, touches Control + Shift + moins (pas sur le pav&#xe9; num&#xe9;rique)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1490251095" MODIFIED="1193412322156" TEXT="Changer la famille de polices, utiliser le champ dans la barre d&apos;outil principale."/>
<node CREATED="1124560950717" ID="Freemind_Link_1933333360" MODIFIED="1193412345828" TEXT="Copier la pr&#xe9;sentation d&apos;un n&#x153;ud, touches Alt + C"/>
<node CREATED="1124560950717" ID="Freemind_Link_1921967585" MODIFIED="1193412369000" TEXT="Coller la pr&#xe9;sentation sur un n&#x153;ud, touches Alt + V."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_526328879" MODIFIED="1192810334984" POSITION="right" TEXT="Utiliser les styles">
<node CREATED="1124560950717" ID="Freemind_Link_313120118" MODIFIED="1195045953562">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour appliquer un style, dans le menu contextuel du n&#339;ud choisissez Style &gt; le style de votre choix. Pour acc&#233;l&#233;rer l'application des styles, utilisez les raccourcis claviers qui vous sont divulgu&#233;s dans le menu contextuel du n&#339;ud.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1472364221" MODIFIED="1193666668328">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Si vous &#234;tes un utilsateur exp&#233;riment&#233;, vous pouvez &#233;diter les styles dans le fichier &quot;patterns.xml&quot; situ&#233; dans le r&#233;pertoire &quot;.freemind&quot; du dossier racine de l'application.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1514218661" MODIFIED="1193666704984">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      [Ce paragraphe est obsol&#232;te] A remark on the file patterns.xml follows. Physical style applies to n&#339;ud, if there is a &lt;node&gt; tag. It applies to edge, if there is an &lt;edge&gt; tag. &lt;node&gt; tag can have tag as a child. Study the file &quot;patterns.xml&quot; supplied with FreeMind.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1697687428" MODIFIED="1192810378062" POSITION="right" TEXT="Mettre en valeur des n&#x153;uds avec les nuages">
<node CREATED="1124560950717" ID="Freemind_Link_1216114345" MODIFIED="1193666813203">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les nuages sont bien adapt&#233;s pour la mise en valeur d'une r&#233;gion. La mise en valeur s'applique &#224; un n&#339;ud et tous ses descendants.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_454267551" MODIFIED="1193666867687">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour ajouter un nuage, touches Ctrl + Shift + B ou Ins&#233;rer &gt; Nuage dans le menu contextuel du n&#339;ud.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_24021567" MODIFIED="1193666929812">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour changer la couleur d'un nuage, Pr&#233;sentation &gt; Couleur du nuage dans le menu contextuel du n&#339;ud.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1607216642" MODIFIED="1193666988078">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les nuages peuvent utiliser diff&#233;rentes couleurs de fond, comme le vert...
    </p>
  </body>
</html>
</richcontent>
<cloud COLOR="#e1f2e1"/>
<node CREATED="1124560950717" ID="Freemind_Link_1420920637" MODIFIED="1193667005843" TEXT="... ou le marron.">
<cloud COLOR="#cc9900"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_203858515" MODIFIED="1192810397781" POSITION="right" TEXT="Ajouter un hyperlien">
<node CREATED="1124560950717" ID="Freemind_Link_224008087" MODIFIED="1193667122500">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Ajouter un hyperlien &#224; un n&#339;ud, touches Ctrl + K ou Ins&#233;rer &gt; Lien dans le menu contextuel du n&#339;ud.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_789925322" MODIFIED="1193667208984">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour retirer un hyperlien, validez un champ vide apr&#232;s avoir tap&#233; Ctrl + K.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_97422033" MODIFIED="1193667294546">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour lier une adresse mail, validez une adresse au format <i>mailto:paul.toto@supermail.com</i>
    </p>
  </body>
</html>
</richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_325647039" MODIFIED="1193667359015">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour lier une adresse mail en pr&#233;cisant un sujet, validez une adresse au format <i>mailto:paul.toto@supermail.com?subject=Dernier appel t&#233;l&#233;phonique</i>
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1046747190" MODIFIED="1195046049218">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Des liens peuvent &#234;tre cr&#233;&#233;s vers des pages internet, des fichiers locaux ou des adresses emails.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1044397139" MODIFIED="1192810409000" POSITION="right" TEXT="Ajouter des ic&#xf4;nes">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1719246999" MODIFIED="1193667461828">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Un n&#339;ud peut avoir plusieurs ic&#244;nes.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_573733331" MODIFIED="1193667753437">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour ajouter une ic&#244;ne &#224; un n&#339;ud, s&#233;lectionnez un n&#339;ud et cliquez l'une des ic&#244;nes de la barre d'outils &#224; gauche. Pendant votre d&#233;placement vers cette barre d'outils, maintenez la touche ALT ou CRTL press&#233;e pour ne pas perdre le focus sur le n&#339;ud &#224; ic&#244;niser.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_192593700" MODIFIED="1193667795812">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour retirer une ic&#244;ne, cliquez sur la croix rouge en haut de la barre d'outils.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1662563363" MODIFIED="1193667830515">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour retirer toutes les ic&#244;nes, cliquez sur la poubelle en haut de la barre d'outils.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_946113090" MODIFIED="1193667876156">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour ajouter une ic&#244;ne sans passer par la barre d'outils, touches Alt + I.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1880472460" MODIFIED="1193667939125">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Il n'y a pas moyen d'utiliser vos propres ic&#244;nes; votre choix est restreint &#224; ceux offerts par FreeMind uniquement.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_312730062" MODIFIED="1193668055843">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour afficher ou masquer la barre d'ic&#244;nes, faites ce choix dans le menu contextuel de l'arri&#232;re plan.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1874089667" MODIFIED="1193668137062">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Quelques exemples d'ic&#244;nes attach&#233;es &#224; ce n&#339;ud.
    </p>
  </body>
</html>
</richcontent>
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1996597932" MODIFIED="1192810425812" POSITION="right" TEXT="Ajouter des liens graphiques">
<node CREATED="1124560950717" ID="Freemind_Link_1758636421" MODIFIED="1193668296281">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour cr&#233;er un lien graphique entre deux n&#339;uds, glissez d&#233;posez un n&#339;ud sur un autre en maintenant press&#233;es les touches CTRL + SHIFT; relachez le bouton de la souris avant de relacher les touches du clavier.
    </p>
  </body>
</html>
</richcontent>
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="255;0;" ID="Freemind_Arrow_Link_1428344028" STARTARROW="None" STARTINCLINATION="255;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_976877624" MODIFIED="1193668358765" TEXT="Vous pouvez aussi glisser d&#xe9;poser avec le bouton droit de la souris."/>
<node CREATED="1124560950717" ID="_Freemind_Link_208378337" MODIFIED="1193668408843">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour changer la couleur d'un lien, utilisez le menu contextuel du lien (clic droit sur le lien graphique).
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1484370636" MODIFIED="1193668447765">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour changer les fl&#232;ches d'un lien, utilisez le menu contextuel du lien.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1406908692" MODIFIED="1193668471203" TEXT="Pour effacer un lien, utilisez le menu contextuel du lien."/>
<node CREATED="1124560950717" ID="_Freemind_Link_266716332" MODIFIED="1193668682046">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour vous d&#233;placer jusqu'&#224; l'un des n&#339;uds aux extr&#233;mit&#233;s d'un lien, utilisez le menu contextuel du lien.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1015289745" MODIFIED="1193668682046" TEXT="Pour changer le parcours d&apos;un lien, glissez le &#xe0; la souris">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="288;21;" ID="Freemind_Arrow_Link_1273596772" STARTARROW="None" STARTINCLINATION="244;32;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_269244121" MODIFIED="1193668702859" TEXT="Ci-dessous un exemple de lien graphique"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_977688660" MODIFIED="1193668711843" TEXT="Exemple">
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1170112929" MODIFIED="1195046155515" TEXT="Lien vers une autre partie">
<arrowlink COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="88;0;" ID="Freemind_Arrow_Link_33407992" STARTARROW="Default" STARTINCLINATION="30;0;"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_490180926" MODIFIED="1193668787703" TEXT="n&#x153;ud avec un sous-n&#x153;ud pli&#xe9;">
<node CREATED="1124560950717" ID="_Freemind_Link_1492563156" MODIFIED="1195046155515" TEXT="sous-n&#x153;ud"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1370577235" MODIFIED="1193668824953" TEXT="Un autre lien">
<arrowlink DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="135;77;" ID="Freemind_Arrow_Link_1872050149" STARTARROW="None" STARTINCLINATION="68;40;"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_423038022" MODIFIED="1192810437421" POSITION="right" TEXT="Recherche">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_273115264" MODIFIED="1193669207156">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Trouver du texte &#224; partir d'un n&#339;ud et de tous ses descendants, touches Ctrl + F
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1203897136" MODIFIED="1193669274359">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Trouver l'occurence suivante dans une recherche, touches Ctrl + G
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1540302670" MODIFIED="1193669964265">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour chercher dans toute la carte, positionnez vous sur le n&#339;ud racine en pressant Echap avant la recherche.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_570841087" LINK="http://fr.wikipedia.org/wiki/Algorithme_de_parcours_en_largeur" MODIFIED="1193669859796">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      La recherche utilise l'algorithme de parcours en largeur. Cela correpond &#224; l'id&#233;e que plus un n&#339;ud est profond, plus le niveau de d&#233;tail est important.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1579286138" MODIFIED="1193669918156">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Rappelez vous que la recherche ne concerne qu'un n&#339;ud et ses descendants, pas toute la carte.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_653540280" MODIFIED="1192810455671" POSITION="right" TEXT="S&#xe9;lectionner plusieurs n&#x153;uds">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1806933639" MODIFIED="1195046241578" TEXT="Pour s&#xe9;lectionner plusieurs n&#x153;uds, touches CTRL + Clic ou SHIFT + Clic">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_523221892" MODIFIED="1193670123359">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Ajouter des n&#339;uds isol&#233;s &#224; une s&#233;lection, touche CTRL + Clic
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1581041000" MODIFIED="1193670236093">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      S&#233;lectionner des n&#339;uds contigus, touche SHIFT en cliquant, ou SHIFT + les touches fl&#232;ches.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1816096007" MODIFIED="1193670378796">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      S&#233;lectionner une branche compl&#232;te, touche ALT + Clic, ou maintenir SHIFT pendant le mouvement d'un n&#339;ud vers son parent avec les touches fl&#232;ches.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_652705856" MODIFIED="1193670449140">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Annuler la s&#233;lection de multiples n&#339;uds, cliquer sur l'arri&#232;re-plan de la carte ou sur un n&#339;ud non s&#233;lectionn&#233;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_740873023" MODIFIED="1193670545140">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      S&#233;lectionner tous les n&#339;uds visibles, &#201;diter &gt; S&#233;lectionner ce qui est visible
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1993740723" MODIFIED="1193670613937">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      S&#233;lectionner les n&#339;uds visibles d'une branche, &#201;diter &gt; S&#233;lectionner la branche visible
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1024903226" MODIFIED="1192810505312" POSITION="right" TEXT="Glisser et d&#xe9;poser">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_627118025" MODIFIED="1194611011937" TEXT="Vous pouvez d&#xe9;placer les n&#x153;uds en utilisant le Glisser&#x2013;D&#xe9;poser">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1127015636" MODIFIED="1194611115109" TEXT="Pour d&#xe9;poser un n&#x153;ud en tant qu&apos;enfant, placer le curseur sur la partie externe du n&#x153;ud.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_883470915" MODIFIED="1194611192046" TEXT="Pour d&#xe9;poser un n&#x153;ud en tant que fr&#xe8;re, placer le curseur sur la partie sup&#xe9;rieuredu n&#x153;ud cible.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1994214827" MODIFIED="1194611287468" TEXT="Pour copier des n&#x153;uds plut&#xf4;t que les bouger, touche CTRL pendant le Glisser, ou glisser avec le bouton du milieu de la souris.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1955993866" MODIFIED="1194612446281">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour &#233;diter une carte existante, glisser son fichier et le d&#233;poser sur l'arri&#232;re-plan de Freemind; en tout cas, cela fonctionne en environnement Microsoft Windows.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1336366619" MODIFIED="1194612514203" TEXT="Pour cr&#xe9;er un lien graphique, glisser et d&#xe9;poser avec le bouton droit de la souris."/>
<node CREATED="1124560950717" ID="Freemind_Link_263153857" MODIFIED="1194612562406" TEXT="Si vous avez s&#xe9;lectionn&#xe9; plusieurs n&#x153;uds, il seront tous d&#xe9;plac&#xe9;s ou copi&#xe9;s.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_105531795" MODIFIED="1194612673406">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vous pouvez d&#233;poser des donn&#233;es issues d'autres applications, comme des fichiers du syst&#232;me de fichiers de Microsoft Windows, ou des extraits de texte s&#233;lectionn&#233;s dans Microsoft Internet Explorer.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#338800" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_958781924" MODIFIED="1192810497578" POSITION="right" TEXT="Copier et coller">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1571910999" MODIFIED="1194613475031">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vous pouvez bien entendu copier et coller des n&#339;uds entre plusieurs cartes mentales . En outre, vous pouvez coller du texte normal ou HTML issu d'autres applications.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_165406975" MODIFIED="1195046364406">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Si vous collez du texte simple, chaque ligne sera coll&#233;e comme un nouveau n&#339;ud, leur profondeur &#233;tant d&#233;termin&#233;e par le nombre d'espaces qui pr&#233;c&#232;de le texte. Vous trouverez un exemple ci-dessous.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_943101487" MODIFIED="1194615034390">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Arbre<br />&#160;&#160;&#160;&#160;&#160;Ch&#234;ne<br />&#160;&#160;&#160;&#160;&#160;H&#234;tre<br />&#160;&#160;&#160;&#160;&#160;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1124560950717" ID="Freemind_Link_267060832" MODIFIED="1194613811843" TEXT="sera coll&#xe9; en">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_285220432" MODIFIED="1194613822250" TEXT="Arbre">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_352947280" MODIFIED="1194613828937" TEXT="Ch&#xea;ne">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_1194865403" MODIFIED="1194615039296" TEXT="H&#xea;tre">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_157221316" MODIFIED="1194614023296">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Si vous collez du HTML, il sera coll&#233; en texte simple. De plus, les liens contenus dans le HTML serons coll&#233;s en tant qu'enfants d'un n&#339;ud additionnel libell&#233; &quot;Liens&quot;. Un exemple suit.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_940552864" MODIFIED="1194614568937" TEXT="R&#xe9;sultat de l&apos;exemple apr&#xe8;s collage">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1484951435" MODIFIED="1194614591734" TEXT="Courses (120236)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_275151874" MODIFIED="1194614602390" TEXT="Vie Urbaine (19)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_39742718" MODIFIED="1194614642968" TEXT="Liens">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_95869894" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1194614611140" TEXT="Courses">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1132489344" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1194614621859" TEXT="Vie Urbaine">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_413367976" MODIFIED="1194614713343" TEXT="Si vous copiez une liste de fichiers s&#xe9;lectionn&#xe9;s dans l&apos;explorateur Microsoft Windows, il seront coll&#xe9;s comme des liens vers ces fichiers."/>
<node CREATED="1124560950717" ID="Freemind_Link_75825075" MODIFIED="1195046422968">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Si vous copiez une branche dans FreeMind et que vous la collez dans un &#233;diteur de texte simple, l'arbre de la structure sera mat&#233;rialis&#233; par une indentation. Les hyperliens seront coll&#233;s entre les signes &lt;&gt;. Un exemple suit.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_739845612" MODIFIED="1194614957578" TEXT="Arbre">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_1866748000" MODIFIED="1194614966171" TEXT="Ch&#xea;ne">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_446449973" MODIFIED="1194614991250" TEXT="H&#xea;tre">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1270096625" MODIFIED="1194615002000" TEXT="est coll&#xe9; en">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_910586297" MODIFIED="1194615021984">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Arbre<br />&#160;&#160;&#160;&#160;&#160;Ch&#234;ne<br />&#160;&#160;&#160;&#160;&#160;H&#234;tre<br />&#160;&#160;&#160;&#160;&#160;Google &lt;http://www.google.com/&gt;<br />
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_845756696" LINK="http://www.google.com/" MODIFIED="1124560950732" TEXT="Google">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_262200214" MODIFIED="1194615859265">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Si vous copiez une branche dans FreeMind et que vous la collez dans un &#233;diteur de texte qui interpr&#232;te le Rich Text Format, les enrichissements seront &#233;galement coll&#233;s, y compris les couleurs et les polices. Les liens hypertextes seront coll&#233;s entre les signes &lt;&gt;, comme pour le texte simple. Parmi les &#233;diteurs qui interpr&#232;tent le Rich Text Format on trouve Microsoft Word, Wordpad ou Microsoft Outlook et quelques outils de prise de notes sous Linux.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_887004814" MODIFIED="1194616011437">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour copier un n&#339;ud sans ses descendants, touche Ctrl + Maj + C ou Copier un seul dans le menu contextuel du n&#339;ud.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="_Freemind_Link_1540212684" MODIFIED="1192810522484" POSITION="right" TEXT="D&#xe9;placements">
<node CREATED="1124560950732" ID="Freemind_Link_1532831156" MODIFIED="1194616061812" TEXT="Bouger le cuseur en haut, bas, droite, gauche: touches fl&#xe8;ches"/>
<node CREATED="1124560950732" ID="Freemind_Link_1026776343" MODIFIED="1194616134703" TEXT="Se d&#xe9;placer au sommet du sous-arbre en cours, touche Page Haut."/>
<node CREATED="1124560950732" ID="Freemind_Link_1123971397" MODIFIED="1194616173703" TEXT="Se d&#xe9;placer &#xe0; la base du sous-arbre en cours, touche Page Bas."/>
<node CREATED="1124560950732" ID="Freemind_Link_1013036835" MODIFIED="1194616216265" TEXT="Se d&#xe9;placer jusqu&apos;au n&#x153;ud central, touche Echap"/>
<node CREATED="1124560950732" ID="_Freemind_Link_97763226" MODIFIED="1194616449093">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour positionner librement un n&#339;ud, glissez sa poign&#233;e invisible situ&#233;e sur le cot&#233; du n&#339;ud en direction de la racine, et d&#233;placez la.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_4727471" MODIFIED="1192810533703" POSITION="right" TEXT="Plier et d&#xe9;plier">
<node CREATED="1124560950732" ID="Freemind_Link_1287425723" MODIFIED="1194616814031" TEXT="Plier/d&#xe9;plier un n&#x153;ud: touche espace ou cliquer sur Plier/d&#xe9;plier dans le menu contextuel du n&#x153;ud."/>
<node CREATED="1124560950732" ID="Freemind_Link_317691799" MODIFIED="1194616926843">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      D&#233;plier un n&#339;ud: touche espace ou cliquer sur Plier/d&#233;plier dans le menu contextuel du n&#339;ud ou encore touche fl&#232;che dans la direction du d&#233;pliage.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1275857415" MODIFIED="1194617117546">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour plier ou d&#233;plier les n&#339;uds par niveaux, maintenir la touche Alt en utilisant la roulette de la souris, ou les touches Alt + Page Haut ou Alt + Page Bas. Attention, les cartes de gros volume peuvent provoquer des probl&#232;mes de m&#233;moire.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1445564893" MODIFIED="1194618441703">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour tout d&#233;plier, cliquer sur le signe plus gris de la barre d'outils principale, ou menu Navigation &gt; Tout d&#233;plier.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1061336625" MODIFIED="1194618500968">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour tout plier, cliquer sur le signe moins gris de la barre d'outils principale, ou menu Navigation &gt; Tout plier.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_679380718" MODIFIED="1194618589421">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Un n&#339;ud pli&#233; est symbolis&#233; par un petit cercle sur son cot&#233; ext&#233;rieur.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_516331171" MODIFIED="1192810566656" POSITION="right" TEXT="Passer &#xe0; une autre carte mentale">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1886120672" MODIFIED="1194618691218">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour modifier une autre carte d&#233;j&#224; ouverte, clic droit sur l'arri&#232;re-plan choisissez la carte parmi celles propos&#233;es dans le menu contextuel.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_467411537" MODIFIED="1192810589859" POSITION="right" TEXT="Faire d&#xe9;filer la carte">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_337651112" MODIFIED="1194618889031">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour faire d&#233;filer la carte, glisser l'arri&#232;re-plan avec la souris, ou utiliser la roulette de la souris. Pour faire d&#233;filer horizontalement avec la roulette de la souris, maintenir la touche Shift press&#233;e ou un des boutons de la souris.
    </p>
  </body>
</html>
</richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913137192" MODIFIED="1192810596000" POSITION="right" TEXT="Zoomer">
<node CREATED="1124560950732" ID="Freemind_Link_233771760" MODIFIED="1194619018281">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour zoomer, utiliser la roulette de la souris en maintenant la touche CTRL press&#233;e, ou touches Alt + fl&#232;che haut ou bas. Vous pouvez aussi utilliser le champ zoom de la barre d'outils principale.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1318678369" MODIFIED="1192810610046" POSITION="right" TEXT="Utiliser l&apos;annulation">
<node CREATED="1124560950732" ID="Freemind_Link_112252182" MODIFIED="1194619084765" TEXT="D&#xe9;faire: touches CTRL + Z, ou menu &#xc9;diter &gt; Annuler"/>
<node CREATED="1124560950732" ID="Freemind_Link_1119630561" MODIFIED="1194619123187" TEXT="Refaire: touches CTRL + Y, ou menu use &#xc9;diter &gt; Refaire"/>
<node CREATED="1124560950732" ID="Freemind_Link_939166656" MODIFIED="1195046667312" TEXT="Pour param&#xe9;trer le nombre d&apos;&#xe9;tapes d&apos;annulations potentielles, menu Outils &gt; Propri&#xe9;t&#xe9;s"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_22510332" MODIFIED="1192810621062" POSITION="right" TEXT="Exporter en HTML">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_407018809" MODIFIED="1194619945093">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Exporter une branche en HTML: touche CTRL + H. Les pages export&#233;es en HTML peuvent embarquer des fonctionnalit&#233;s de pliage, param&#233;trable dans le menu Outils &gt; Propri&#233;t&#233;s &gt; HTML
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1302491778" MODIFIED="1194620129468" TEXT="Pour utiliser une autre fonction d&apos;export, menu Fichier &gt; Exporter &gt; En XHTML (version Javascript)"/>
<node CREATED="1124560950732" ID="Freemind_Link_1434016102" MODIFIED="1194620287234">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Exporter la carte avec une image d'ensemble cliquable sous HTML, menu Fichier &gt; Export &gt; En XHTML (image cliquable)
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1908686168" MODIFIED="1194620305046" POSITION="right" TEXT="Exporter en image pixellis&#xe9;e ou vectoris&#xe9;e">
<node CREATED="1124560950732" ID="Freemind_Link_254470028" MODIFIED="1194620351562">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Exporter la carte en image PNG, menu Fichier &gt; Exporter &gt; En PNG
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_237937736" MODIFIED="1194620399640">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Exporter la carte en image JPEG, menu Fichier &gt; Exporter &gt; En JPEG
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1983744600" MODIFIED="1194620459843">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Exporter la carte en SVG, menu Fichier &gt; Exporter &gt; En SVG. Cette fonction n'est disponible que si vous avez install&#233; le plug-in SVG.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_329770204" MODIFIED="1192810684062" POSITION="right" TEXT="Exporter dans des formats XML">
<node CREATED="1124560950732" ID="Freemind_Link_1640331795" MODIFIED="1194620688421">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Exporter la carte dans un format XML pour lequel vous avec la feuille XSLT, menu Fichier &gt; Exporter &gt; En utilisant une XSLT
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1314963260" MODIFIED="1195046719890">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Exporter la carte dans un document OpenOffice Writer 1.4, menu Fichier &gt; Exporter &gt; Comme document OpenOffice Writer
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1841136119" MODIFIED="1192810708890" POSITION="right" TEXT="Importer la structure du syst&#xe8;me de fichiers">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_947129573" MODIFIED="1194625678515">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour importer la structure des r&#233;pertoires, dans le contexte d'un n&#339;ud, menu Fichier &gt; Importer &gt; Importer une arborescence de r&#233;pertoires. Choisissez le r&#233;pertoire pour lequel vous d&#233;sirez importer l'arborescence. Par arborescence, nous entendons l'arbre de tous les sous-repertoires, avec les liens vers les fichiers que contiennent ces sous-r&#233;pertoires. Suit un exemple d'un arborescence import&#233;e.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_194372032" MODIFIED="1194625640953" TEXT="Exemple">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_544626837" MODIFIED="1195046790515" TEXT="R&#xe9;pertoire choisi">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1055412959" LINK="C:\Program Files\Microsoft Office\Office\Bitmaps" MODIFIED="1124560950732" TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_262747655" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/" MODIFIED="1124560950732" TEXT="Dbwiz">
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/ASSETS.GIF" MODIFIED="1124560950732" TEXT="ASSETS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF" MODIFIED="1124560950732" TEXT="CONTACTS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF" MODIFIED="1124560950732" TEXT="EVTMGMT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF" MODIFIED="1124560950732" TEXT="EXPENSES.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF" MODIFIED="1124560950732" TEXT="INVENTRY.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/LEDGER.GIF" MODIFIED="1124560950732" TEXT="LEDGER.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF" MODIFIED="1124560950732" TEXT="ORDPROC.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF" MODIFIED="1124560950732" TEXT="RESOURCE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/SERVICE.GIF" MODIFIED="1124560950732" TEXT="SERVICE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF" MODIFIED="1124560950732" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_814519219" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/" MODIFIED="1124560950732" TEXT="Styles">
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF" MODIFIED="1124560950732" TEXT="ACBLENDS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" MODIFIED="1124560950732" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF" MODIFIED="1124560950732" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF" MODIFIED="1124560950732" TEXT="ACINDSTR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF" MODIFIED="1124560950732" TEXT="ACRICEPR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF" MODIFIED="1124560950732" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF" MODIFIED="1124560950732" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_269203785" MODIFIED="1192810728296" POSITION="right" TEXT="Importer les favoris d&apos;Internet Explorer">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_260446736" MODIFIED="1195046836953">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Pour importer les favoris d'Internet Explorer dans FreeMind, menu Fichier &gt; Importer &gt; Favoris d'Explorer. Entrez le r&#233;pertoire o&#249; sont stock&#233;s les favoris. Le nom du r&#233;pertoire est &quot;favoris&quot;. En Windows 2000 vous le trouverez sur votre disque dans le chemin C:\Documents and Settings\&lt;user&gt;\Favoris
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="Freemind_Link_908726543" MODIFIED="1194626096328" TEXT="Mots cl&#xe9;s: Microsoft Internet Explorer, MSIE, MS IE.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1709974530" MODIFIED="1192810757171" POSITION="right" TEXT="Importer une carte mentale de MindManager X5">
<node CREATED="1124560950732" ID="Freemind_Link_1459845334" MODIFIED="1194626922593" TEXT="menu Fichier &gt; Importer &gt; Carte de MindManager X5"/>
</node>
<node COLOR="#338800" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913645795" MODIFIED="1192810772234" POSITION="right" TEXT="Integration avec Word ou Outlook">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_459841375" MODIFIED="1195046868640">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vous pouvez coller des cartes ou des branches dans Microsoft Word, Wordpad ou dans des messages Outlook. En g&#233;n&#233;ral, vous le pouvez dans toute application qui interpr&#232;te le format Rich Text Format. Le formatage du texte et les liens sont &#233;galement copi&#233;s.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_12899097" MODIFIED="1195046934203">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vous pouvez &#233;galement coller une carte dans Microsoft Word en l'exportant au format HTML avec en-t&#234;tes, puis en copiant le HTML dans Word.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_953624663" LINK="mailto:don.bonton@supermail.com" MODIFIED="1194627730859">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Cliquer sur un lien mail (mailto:don.bonton@supermail.com) ouvrira votre messagerie pour cr&#233;er un nouveau message.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1495500722" LINK="mailto:don.bonton@supermail.com?subject=Last phone call" MODIFIED="1194627700937" TEXT="Vous pouvez ajouter un sujet au mail (mailto:don.bonton@supermail.com?subject=Last phone call)"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1822195277" MODIFIED="1194627892875" POSITION="right" TEXT="D&#xe9;finir les propri&#xe9;t&#xe9;s">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1234344968" MODIFIED="1194628002125">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      menu Outils &gt; Propri&#233;t&#233;s. La plupart des changements prennent effet apr&#232;s un red&#233;marrage de FreeMind.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_259902657" MODIFIED="1194628153515">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les propri&#233;t&#233;s incluent les raccourcis claviers, les caract&#233;ristiques de l'export HTML, la fa&#231;on de s&#233;lectionner un n&#339;ud avec la souris, le lissage et plus encore.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="Freemind_Link_672541576" MODIFIED="1194628188687" TEXT="Mot cl&#xe9;s: personnaliser">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1528828442" MODIFIED="1192810794812" POSITION="right" TEXT="Imprimer">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_695293333" MODIFIED="1195047112703">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vou pouvez imprimer soit en ajustant la carte sur une page, ou en utilisant plusieurs feuilles de papier. Vous faites ce choix dans le menu: Fichier &gt; Mise en Page
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_467598056" MODIFIED="1194965906984" TEXT="Pour une utilisation optimale de l&apos;espace, choisissez le format Paysage de la mise en page.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_296135096" MODIFIED="1194966273234">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      L'aper&#231;u de votre carte avant impression n'est pas direct. Si vous poss&#233;dez une imprimante postscript ou un driver postscript g&#233;n&#233;rique, vous pouvez imprimer la carte dans un fichier et visionner la carte en utilisant Ghosview ou un logiciel &#233;quivalent. Si vous essayez d'imprimer la carte avec une imprimante qui ne g&#232;re pas le postscript, le fichier r&#233;sultant ne sera pas en postcript mais probablement en PCL, format inutilisable pour vous.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1073337160" MODIFIED="1194966934781">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Vous pouvez &#233;galement imprimer depuis votre navigateur internet apr&#232;s un export HTML, ou depuis Word ou Wordpad apr&#232;s y avoir copi&#233;/coll&#233; la carte. Si vous exportez la carte en HTML avec en-t&#234;tes et que vous la copiez/collez dans Microsoft Word, vous pourrez modifier les styles &#224; votre convenance.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_841140408" MODIFIED="1192811302546" POSITION="right" TEXT="Utiliser du texte riche dans les n&#x153;uds gr&#xe2;ce &#xe0; l&apos;HTML">
<node CREATED="1124560950732" ID="Freemind_Link_585709190" MODIFIED="1195047189578">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Les n&#339;uds commen&#231;ant par &lt;html&gt; sont mis en forme en utilisant le HTML qu'ils contiennent. Cette fonctionnalit&#233; est utile aux personnes avec des dispositions technique. Par exemple:
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1151602814" MODIFIED="1194967309218">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        body { color: #000000; font-family: SansSerif; font-size: 12pt }
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <h3>
      Exemple HTML
    </h3>
    <p class="msonormal">
      Plusieurs points:
    </p>
    <ul type="disc">
      <li>
        Point un
      </li>
      <li>
        Point deux
      </li>
    </ul>
    <p class="msonormal">
      Nous avons des caract&#232;res <b>gras</b> ou <i>italiques</i>. <u>Soulingn&#233;s</u> et <strike>barr&#233;</strike> &#233;galement. Un petit tableau:
    </p>
    <table class="msonormaltable" cellspacing="0" style="border: none" cellpadding="0" border="1">
      <tr>
        <td style="border: solid windowtext 1.0pt; padding-left: .75pt; padding-bottom: .75pt; padding-top: .75pt; padding-right: .75pt">
          <p class="msonormal">
            Cellule1
          </p>
        </td>
        <td style="border-left: none; border: solid windowtext 1.0pt; padding-left: .75pt; padding-bottom: .75pt; padding-top: .75pt; padding-right: .75pt">
          <p class="msonormal">
            Cellule2
          </p>
        </td>
      </tr>
      <tr>
        <td style="border: solid windowtext 1.0pt; padding-left: .75pt; padding-bottom: .75pt; padding-top: .75pt; padding-right: .75pt; border-top: none">
          <p class="msonormal">
            Cellule3
          </p>
        </td>
        <td style="border-left: none; border-bottom: solid windowtext 1.0pt; padding-left: .75pt; padding-bottom: .75pt; padding-top: .75pt; border-right: solid windowtext 1.0pt; padding-right: .75pt; border-top: none">
          <p class="msonormal">
            Cellulle4
          </p>
        </td>
      </tr>
    </table>
    <p class="msonormal">
      &#160;Plusieurs <font color="#999900">couleurs</font> de <font color="#336600">caract&#232;res</font> sont possibles.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1349362347" MODIFIED="1194967673375">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      L'export des n&#339;uds et des images HTML n'est pas support&#233; en texte ou RTF (Word, Wordpad). En fait, le HTML est pratique dans le cadre d'une publication sur le Web utilis&#233;e conjointement avec l'Applet FreeMind.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_271176250" MODIFIED="1192811328859" POSITION="right" TEXT="Utiliser des images dans les n&#x153;uds">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1724581202" MODIFIED="1195047227640">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Ins&#233;rer une image dans FreeMind: touches Alt + K, ou dans le menu contextuel du n&#339;ud Inser&#233;r &gt; Image. L'insertion d'une image efface le texte d&#233;j&#224; pr&#233;sent dans le n&#339;ud. Les images inser&#233;es par cette m&#233;thode ne sont pas coll&#233;es correctement en dehors de FreeMind et ne sont pas non plus bien export&#233;es en HTML. La gestion des images dans FreeMind en est &#224; ses balbutiements.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1206759193" MODIFIED="1194967950640" TEXT="Les formats d&apos;images g&#xe9;r&#xe9;s sont les PNG, JPEG et GIF."/>
<node CREATED="1124560950732" ID="Freemind_Link_281524923" MODIFIED="1194968087984">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Transformer un lien vers une image en image visible: touches Alt + K. Vous pouvez glisser-d&#233;poser plusieurs fichiers d'images dans FreeMind, s&#233;lectionnez les comme n&#339;uds multiples, et transformez les en images en pressant les touches Alt + K.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#000000" CREATED="1124560950732" ID="Freemind_Link_1654024039" MODIFIED="1194968260062">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Il existe une approche plus technique et moins facile d'acc&#232;s pour ins&#233;rer une image. Il est possible d'inclure du HTML dans les n&#339;uds. D&#233;marrez le contenu du n&#339;ud avec la balise &lt;html&gt;. De cette mani&#232;re, vous pouvez afficher des images dans les n&#339;uds.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1390666393" MODIFIED="1194968283781">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Par exemple<br />&#160;&#160;&lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;<br />&#160;&#160;&lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;<br />
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1043020605" MODIFIED="1194968344031" TEXT="Vous pouvez utiliser des liens relatifs pour les images">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1825247742" MODIFIED="1194968391453" TEXT="Exemple d&apos;images, fonctionne sur certaines versions de Windows">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1688770779" MODIFIED="1194968725078">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        body { background-color: #ffffff; font-size: 12pt; font-family: SansSerif }
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Windows/Help/Tours/htmltour/Connected_networks.jpg" />
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_163698799" MODIFIED="1194968767171">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Windows/Help/Tours/htmltour/Connected_wizard.jpg" />
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1915243487" MODIFIED="1194968806046">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Windows/Help/Tours/htmltour/Connected_multiple.jpg" />
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1124560950732" ID="Freemind_Link_453092767" MODIFIED="1194968853953">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Windows/Help/Tours/htmltour/end_up.jpg" />
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1332419976" MODIFIED="1193212505265">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Program Files/Microsoft Office/Office11/Bitmaps/Styles/ACRICEPR.GIF" />
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1799711958" MODIFIED="1193212511062">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Program Files/Microsoft Office/Office11/Bitmaps/Styles/ACSNDSTN.GIF" />
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1124560950732" ID="Freemind_Link_1719958498" MODIFIED="1193212516703">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Program Files/Microsoft Office/Office11/Bitmaps/Styles/ACSUMIPT.GIF" />
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_767819854" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" ID="Freemind_Link_768730129" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_825964200" MODIFIED="1194971276828" POSITION="right" TEXT="Utiliser le verrouillage de fichier exp&#xe9;rimental">
<node CREATED="1124560950732" ID="Freemind_Link_789648148" MODIFIED="1194971242140">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      La version actuelle de FreeMInd exp&#233;rimente le verrouillage de fichier, d&#233;sactiv&#233; par d&#233;faut. L'impl&#233;mentation courante ne g&#232;re pas parfaitement les situations de comp&#233;tition, mais &#231;a devrait fonctionner pour les usages les plus pratiques.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_926280662" MODIFIED="1194971252562">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      Le verrouillage de fichier emp&#234;che l'acc&#232;s simultan&#233; de plusieurs utilisateurs &#224; une m&#234;me carte, ce qui &#233;vite aux uns d'effacer accidentellement les donn&#233;es des autres.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1685212526" MODIFIED="1194971188218" TEXT="Pour d&#xe9;marrer le verrouillage de fichier experimental, menu Outils &gt; Prorpri&#xe9;t&#xe9;s &gt; Environnement"/>
</node>
</node>
</map>
